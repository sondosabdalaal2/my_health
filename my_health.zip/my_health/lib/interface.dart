import 'package:flutter/material.dart';
import 'background.dart';
import 'package:my_health/constants.dart';
import 'package:my_health/components/animation_page.dart';
import 'package:my_health/Screens/Welcome/doctor/doctor_welcome_screen.dart';
import 'package:my_health/Screens/Welcome/patient/patient_welcom_screen.dart';
import 'package:my_health/Screens/Login/senior_manager/manager_login.dart';

class Interfaces extends StatefulWidget {
  @override
  _InterfacesState createState() => _InterfacesState();
}

class _InterfacesState extends State<Interfaces> with SingleTickerProviderStateMixin {
  AnimationController controller;
  // Animation animation;
  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
      upperBound: 100.0,
    );
    controller.forward();
    controller.addListener(() {
      setState(() {});
    });
    // print(controller.value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Background(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: 30.0,
              ),
              Text('Choose your interface:',style: TextStyle(fontSize: 18.0),),
              SizedBox(height: 20.0,),
              AnimationPage(
                text: 'Patient',
                page: PatientWelcomeScreen(),
                buttonColor: kPrimaryColor,
                textColor: Colors.white,
              ),
              AnimationPage(
                text: 'Doctor',
                page: DoctorWelcomeScreen(),
                buttonColor: kPrimaryLightColor,
                textColor: Colors.black,
              ),
              AnimationPage(
                text: 'Senior Manager',
                page: ManagerLogin(),
                buttonColor: kPrimaryColor,
                textColor: Colors.white,
              ),


            ],
          ),
        ),
      ),
    );
  }
}
