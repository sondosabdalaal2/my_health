import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class HorizontalLine extends StatelessWidget {
  const HorizontalLine({
    this.height,
  });

  final double height;

  @override
  Widget build(BuildContext context) {

    return Row(children: <Widget>[
      Expanded(
        child: Container(
            margin: EdgeInsets.only(left: 10.0, right: 15.0),
            child: Divider(
              color: Colors.black,
              height: height,
            )),
      ),

      // Expanded(
      //   child: Container(
      //       margin: const EdgeInsets.only(left: 15.0, right: 10.0),
      //       child: Divider(
      //         color: Colors.black,
      //         height: height,
      //       )),
      // ),
    ]);
  }
}