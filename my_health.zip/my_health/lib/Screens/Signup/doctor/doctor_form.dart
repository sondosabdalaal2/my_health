import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/login_screen.dart';
import 'package:my_health/Screens/Signup/components/background.dart';
import 'package:my_health/components/already_have_an_account_acheck.dart';
import 'package:my_health/components/rounded_button.dart';
import 'package:my_health/components/rounded_input_field.dart';
import 'package:my_health/components/rounded_password_field.dart';
import 'package:my_health/components/text_field_container.dart';
import 'package:my_health/constants.dart';
import 'package:intl/intl.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:my_health/Screens/MainPages/doctor_main_page/main_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DoctorForm extends StatefulWidget {
  @override
  _DoctorFormState createState() => _DoctorFormState();
}

class _DoctorFormState extends State<DoctorForm> {
  final TextEditingController textController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController idController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  DateTime _birthDate;
  bool showSpinner;
  String type;
  String _email,_password,_fullName,_id,_bd,_phoneNumber;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final user = FirebaseFirestore.instance.collection('Doctors');

  String validateMobile(String value) {
    if (value.isEmpty) {
      return 'Enter the phone number';
    } else if (value.length != 10)
      return 'Mobile Number must be of 10 digit';
    else
      return null;
  }
  Future<void> userSetup(
      String fullname,
      String email,
      String birthdate,
      String phone,
      String id,

     ) async {
    CollectionReference users =
    FirebaseFirestore.instance.collection('Doctors');
    FirebaseAuth auth = FirebaseAuth.instance;
    String uid = auth.currentUser.email.toString();
    String userid=auth.currentUser.uid.toString();
    users.add({
      'fullName': fullname,
      'email': uid,
      'birthdate': birthdate,
      'phone': phone,
      'ID': id,
      'uid':userid

    });
    return;
  }

  @override
  void dispose() {
    textController.dispose();
    emailController.dispose();
    passController.dispose();
    phoneController.dispose();
    idController.dispose();
    super.dispose();
  }

  final _formKey = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Background(
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                SafeArea(
                  child: Container(
                    color: kPrimaryColor,
                    height: 50.0,
                    width: double.infinity,
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        'Register Form',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 19.0,
                            fontStyle: FontStyle.italic,
                            wordSpacing: 2.0,
                            letterSpacing: 1.5,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: size.height * 0.03),
                RoundedInputField(
                  valid: (value) =>
                  value.isEmpty ? 'Enter your full name' : null,
                  controller: textController,
                  hintText: "Full Name",
                  onChanged: (value) {
                    setState(() {
                      _fullName=value;
                    });
                  },

                ),
                RoundedInputField(
                  valid: (value) => value.isEmpty ? 'Enter your Email' : null,
                  controller: emailController,
                  hintText: "Email",
                  onChanged: (value) {
                    setState(() {
                      _email=value;
                    });
                  },
                  icon: Icons.email,
                ),
                RoundedPasswordField(
                  valid: (value) =>
                  value.isEmpty ? 'Enter your Password' : null,
                  controller: passController,
                  onChanged: (value) {
                    setState(() {
                      _password = value;
                    });
                  },
                ),
                RoundedInputField(
                  valid: (value) => value.isEmpty ? 'Enter your practicing ID' : null,
                  controller: idController,
                  hintText: "ID for the practicing the profession",
                  onChanged: (value) {
                    setState(() {
                      _id=value;
                    });
                  },
                  icon: Icons.vpn_key,
                ),
                TextFieldContainer(
                  child: TextField(
                    cursorColor: kPrimaryColor,
                    decoration: InputDecoration(
                      hintText: _birthDate == null
                          ? 'Birthday'
                          : DateFormat('dd-MM-yyyy').format(_birthDate),
                      suffixIcon: IconButton(
                          icon: Icon(
                            Icons.date_range_rounded,
                            color: kPrimaryColor,
                          ),
                          onPressed: () {
                            showDatePicker(
                              context: context,
                              initialDate: DateTime.now(), // Current Date
                              firstDate: DateTime(1900), // First date
                              lastDate: DateTime(2200), // Last Date
                              builder: (BuildContext context, Widget child) {
                                return Theme(
                                    data: ThemeData(
                                      primarySwatch:
                                      txtColor, // Color of Ok and Cancel
                                      primaryColor:
                                      kPrimaryColor, // Select date color
                                      accentColor:
                                      kPrimaryColor, // Select date color
                                    ),
                                    child: child);
                              },
                            ).then((date) {
                              setState(() {
                                _birthDate = date;
                              });
                            });
                          }),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                RoundedInputField(
                  controller: phoneController,
                  valid: validateMobile,
                  hintText: 'Phone Number',
                  onChanged: (value) {
                    setState(() {
                      _phoneNumber=value;
                    });
                  },
                  icon: Icons.phone,
                ),
                RoundedButton(
                  text: "SIGNUP",
                  press: () async{
                    setState(() {
                      showSpinner = true;
                    });
                    try{
                     if(_formKey.currentState.validate()){
                       final newDoctor= await _auth.createUserWithEmailAndPassword(email: _email, password: _password);
                       type='doctor';
                       userID++;
                       if(newDoctor!=null){
                         userSetup(_fullName, _email, _bd, _phoneNumber, _id);
                         Navigator.push(
                             context,
                             PageRouteBuilder(
                               transitionDuration: Duration(seconds: 1),
                               transitionsBuilder: (BuildContext context,
                                   Animation<double> animation,
                                   Animation<double> secAnimation,
                                   Widget child) {
                                 animation = CurvedAnimation(
                                     parent: animation, curve: Curves.easeIn);
                                 return ScaleTransition(
                                   scale: animation,
                                   child: child,
                                   alignment: Alignment.center,
                                 );
                               },
                               pageBuilder: (BuildContext context,
                                   Animation<double> animation,
                                   Animation<double> secAnimation) {
                                 return DoctorMainPage();
                               },
                             )
                         );
                       }
                     }

                    }catch(e){
                      print(e);
                    }
                  },
                ),
                SizedBox(height: size.height * 0.03),
                AlreadyHaveAnAccountCheck(
                  login: false,
                  press: () {
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        transitionDuration: Duration(seconds: 1),
                        transitionsBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secAnimation,
                            Widget child) {
                          animation = CurvedAnimation(
                              parent: animation, curve: Curves.easeIn);
                          return ScaleTransition(
                            scale: animation,
                            child: child,
                            alignment: Alignment.center,
                          );
                        },
                        pageBuilder: (BuildContext context,
                            Animation<double> animation,
                            Animation<double> secAnimation) {
                          return LoginScreen();
                        },
                      ),
                    );
                  },
                ),
                SizedBox(height: size.height * 0.03),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
