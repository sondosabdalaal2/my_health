import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/patient/patient_login.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
