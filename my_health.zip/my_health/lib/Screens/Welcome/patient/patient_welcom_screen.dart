import 'package:flutter/material.dart';
import 'package:my_health/Screens/Welcome/patient/components/body.dart';

class PatientWelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
