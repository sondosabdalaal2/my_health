import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:my_health/components/addButton.dart';
import 'package:my_health/constants.dart';
import 'package:intl/intl.dart';
import 'package:my_health/components/horizontal_line.dart';
class AddDoctor extends StatefulWidget {
  @override
  _AddDoctorState createState() => _AddDoctorState();
}

class _AddDoctorState extends State<AddDoctor> {
  final TextEditingController textController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController idController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  DateTime _birthDate;
  bool showSpinner;
  String type;
  String _email,_password,_fullName,_id,_bd,_phoneNumber;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final user = FirebaseFirestore.instance.collection('Doctors');

  String validateMobile(String value) {
    if (value.isEmpty) {
      return 'Enter the phone number';
    } else if (value.length != 10)
      return 'Mobile Number must be of 10 digit';
    else
      return null;
  }
  Future<void> userSetup(
      String fullname,
      String email,
      String birthdate,
      String phone,
      String id,

      ) async {
    CollectionReference users =
    FirebaseFirestore.instance.collection('Doctors');
    FirebaseAuth auth = FirebaseAuth.instance;
    String uid = auth.currentUser.email.toString();
    String userid=auth.currentUser.uid.toString();
    users.add({
      'fullName': fullname,
      'email': uid,
      'birthdate': birthdate,
      'phone': phone,
      'ID': id,
      'uid':userid

    });
    return;
  }

  @override
  void dispose() {
    textController.dispose();
    emailController.dispose();
    passController.dispose();
    phoneController.dispose();
    idController.dispose();
    super.dispose();
  }

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Form(
          child: Column(
            //key: _formKey,
            children: [
              SizedBox(
                height: 20.0,
              ),
              Container(
                width: size.width * .8,
                child: Text(
                  'Information about Doctor:',
                  style: TextStyle(
                      fontSize: 16,
                      color: kPrimaryColor),
                ),
              ),
              buildTextFieldContainer(
                size: size,
                text: 'Full Name',
                onChange: (value) {
                  setState(() {
                    _fullName = value;
                  });
                },
                valid: (value) => value.isEmpty ? 'Enter Full Name' : null,
                controller: textController,
              ),
              buildTextFieldContainer(
                size: size,
                text: 'Email',
                onChange: (value) {
                  setState(() {
                    _email = value;
                  });
                },
                valid: (value) => value.isEmpty ? 'Enter Email' : null,
                controller: emailController,
              ),
              buildTextFieldContainer(
                size: size,
                text: 'Password',
                onChange: (value) {
                  setState(() {
                    _password = value;
                  });
                },
                valid: (value) => value.isEmpty ? 'Enter Password' : null,
                controller: passController,
              ),
              buildTextFieldContainer(
                size: size,
                text: 'Practicing ID',
                onChange: (value) {
                  setState(
                        () {
                      _id = value;
                    },
                  );
                },
                valid: (value) => value.isEmpty ? 'Enter Practicing ID' : null,
                controller: idController,
              ),
              Container(
                width: size.width * .6,
                child: TextField(
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    hintText: _birthDate == null
                        ? 'Birthday'
                        : DateFormat('dd-MM-yyyy').format(_birthDate),
                    suffixIcon: IconButton(
                        icon: Icon(
                          Icons.date_range_rounded,
                          color: kPrimaryColor,
                        ),
                        onPressed: () {
                          showDatePicker(
                            context: context,
                            initialDate: DateTime.now(), // Current Date
                            firstDate: DateTime(1900), // First date
                            lastDate: DateTime(2200), // Last Date
                            builder: (BuildContext context, Widget child) {
                              return Theme(
                                  data: ThemeData(
                                    primarySwatch:
                                    txtColor, // Color of Ok and Cancel
                                    primaryColor:
                                    kPrimaryColor, // Select date color
                                    accentColor: kPrimaryColor, // Select date color
                                  ),
                                  child: child);
                            },
                          ).then((date) {
                            setState(() {
                              _birthDate = date;
                              _bd = _birthDate.toString();
                            });
                          });
                        }),
                  ),
                ),
              ),
              buildTextFieldContainer(
                size: size,
                text: 'Phone Number',
                onChange: (value) {
                  setState(() {
                    _phoneNumber = value;
                  });
                },
                controller: phoneController,
                valid: validateMobile,
              ),
              SizedBox(
                height: 20.0,
              ),

              AddButton(
                text: 'Add',
                press: () async {
                  setState(() {
                    showSpinner = true;
                  });
                  try {
                    //if (_formKey.currentState.validate()) {
                      final newDoctor = await _auth
                          .createUserWithEmailAndPassword(
                          email: _email, password: _password);
                      type = 'doctor';
                      userID++;
                      if (newDoctor != null) {
                        userSetup(_fullName, _email, _bd, _phoneNumber, _id);
                      }

                      setState(() {
                        showSpinner = false;
                      });
                  //  }
                  } catch (e) {
                    print(e);
                  }
                }),
            ],
          )),
    );
  }
  Container buildTextFieldContainer(
      {Size size,
        String text,
        Function onChange,
        dynamic valid,
        dynamic controller}) {
    return Container(
      width: size.width * .6,
      child: TextFormField(
        validator: valid,
        controller: controller,
        decoration: InputDecoration(
          hintText: text,
        ),
        onChanged: onChange,
      ),
    );
  }
}
