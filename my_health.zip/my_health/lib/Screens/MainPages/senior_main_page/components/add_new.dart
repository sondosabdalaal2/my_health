import 'package:flutter/material.dart';
import 'package:my_health/constants.dart';
import 'tab_bar_container.dart';
import 'add_doctor.dart';
import 'add_patient.dart';
import 'add_patients_doctor.dart';

class Add extends StatefulWidget {
  @override
  _AddState createState() => _AddState();
}

class _AddState extends State<Add> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: SafeArea(
          child: Container(
            margin: EdgeInsets.fromLTRB(12, 0, 12, 0),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _tabBarContainer(),
                  _tabContent(),
                ]
            ),
          ),
        ),
      ),
    );
  }
  Widget _tabBarContainer() => Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(width: 0.3, color: kPrimaryLightColor),
        ),
      ),
      child: TabBar(
          isScrollable: true,
          indicatorSize: TabBarIndicatorSize.label,
          indicator: UnderlineTabIndicator(
              borderSide: BorderSide(width: 2.0, color: kPrimaryColor)),
          unselectedLabelColor: kPrimaryLightColor,
          labelColor: kPrimaryColor,
          labelPadding: EdgeInsets.symmetric(horizontal: 10),
          tabs: [
            Tab(
              child: Align(
                child: Text('Patient',
                    textAlign: TextAlign.start,
                    style:
                    TextStyle(fontSize: 16.0, fontWeight: FontWeight.w600)),
                alignment: Alignment.centerLeft,
              ),
            ),
            Tab(
              child: Align(
                child: Text('Doctor',
                    textAlign: TextAlign.end,
                    style:
                    TextStyle(fontSize: 16.0, fontWeight: FontWeight.w600)),
                alignment: Alignment.centerRight,
              ),
            ),
            Tab(
              child: Align(
                child: Text('Patients-Doctor',
                    textAlign: TextAlign.end,
                    style:
                    TextStyle(fontSize: 16.0, fontWeight: FontWeight.w600)),
                alignment: Alignment.centerRight,
              ),
            ),
          ]));
  Widget _tabContent() => Expanded(
    child: TabBarView(children: [
      AddPatient(),
      AddDoctor(),
      AddPatientDoctor(),
    ]),
  );
}
