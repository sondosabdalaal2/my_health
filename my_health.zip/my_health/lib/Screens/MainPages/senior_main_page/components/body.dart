import 'package:flutter/material.dart';
import 'package:my_health/constants.dart';
import 'background.dart';
import 'placeholder_widget.dart';
import 'package:my_health/Screens/MainPages/senior_main_page/components/design_tab.dart';
import 'add_new.dart';
class Body extends StatefulWidget {
  final name;
  final email;

  Body({this.name,this.email});

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  TabController _controller;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
  final List<Widget> _children = [
    PlaceholderWidget(DesignTab()),
    PlaceholderWidget(Add()),
    PlaceholderWidget(Container()),

  ];
  @override
  void initState() {
    _controller = new TabController(length: 2,vsync: this);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {


    return Background(
      child:_children[_currentIndex],
      name: widget.name,
      email: widget.email,
      builBottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        onTap: onTabTapped, // new
        currentIndex: _currentIndex, // new
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'Add',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),

    );
  }

}

