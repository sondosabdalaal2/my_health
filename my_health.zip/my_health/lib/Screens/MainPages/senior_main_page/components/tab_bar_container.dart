import 'package:flutter/material.dart';
import 'package:my_health/constants.dart';

class TabBarContainer extends StatefulWidget {
  @override
  _TabBarContainerState createState() => _TabBarContainerState();
}

class _TabBarContainerState extends State<TabBarContainer> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(width: 0.3, color: kPrimaryLightColor),
                ),
              ),
              child: TabBar(
                  isScrollable: true,
                  indicatorSize: TabBarIndicatorSize.label,
                  indicator: UnderlineTabIndicator(
                      borderSide: BorderSide(width: 2.0, color: kPrimaryColor)),
                  unselectedLabelColor: kPrimaryLightColor,
                  labelColor: kPrimaryColor,
                  labelPadding: EdgeInsets.symmetric(horizontal: 10),
                  tabs: [
                    Tab(
                      child: Text('Patients',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              fontSize: 16.0, fontWeight: FontWeight.w600)),
                    ),
                    Tab(
                      child: Text('Doctors',
                          textAlign: TextAlign.end,
                          style: TextStyle(
                              fontSize: 16.0, fontWeight: FontWeight.w600)),
                    ),
                  ]))
        ],
      ),
    );
  }
}

// class tabDesign extends StatelessWidget {
//   const tabDesign({
//     Key key,
//   }) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//         decoration: const BoxDecoration(
//           border: Border(
//             bottom: BorderSide(width: 0.3, color: kPrimaryLightColor),
//           ),
//         ),
//         child: TabBar(
//             isScrollable: true,
//             indicatorSize: TabBarIndicatorSize.label,
//             indicator: UnderlineTabIndicator(
//                 borderSide: BorderSide(width: 2.0, color: kPrimaryColor)),
//             unselectedLabelColor: kPrimaryLightColor,
//             labelColor: kPrimaryColor,
//             labelPadding: EdgeInsets.symmetric(horizontal: 10),
//             tabs: [
//               Tab(
//                 child: Align(
//                   child: Text('Patients',
//                       textAlign: TextAlign.start,
//                       style: TextStyle(
//                           fontSize: 16.0, fontWeight: FontWeight.w600)),
//                   alignment: Alignment.center,
//                 ),
//               ),
//               Tab(
//                 child: Align(
//                   child: Text('Doctors',
//                       textAlign: TextAlign.end,
//                       style: TextStyle(
//                           fontSize: 16.0, fontWeight: FontWeight.w600)),
//                   alignment: Alignment.center,
//                 ),
//               ),
//             ]));
//   }
// }
