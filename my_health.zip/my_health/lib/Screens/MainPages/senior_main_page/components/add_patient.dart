import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:my_health/constants.dart';
import 'package:intl/intl.dart';
import 'package:my_health/components/horizontal_line.dart';
import 'package:my_health/components/addButton.dart';

class AddPatient extends StatefulWidget {
  @override
  _AddPatientState createState() => _AddPatientState();
}

class _AddPatientState extends State<AddPatient> {
  TextEditingController textController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController vestIDController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController pPhoneController = TextEditingController();
  TextEditingController pNameController = TextEditingController();

  bool showSpinner;

  DateTime _birthDate;
  String _phoneNumber;
  String _address,
      _pFullName,
      _fullName,
      _pPhoneNum,
      _vId,
      _bd,
      _password,
      _email;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final user = FirebaseFirestore.instance.collection('Patient');

  String validateMobile(String value) {
    if (value.isEmpty) {
      return 'Enter the phone number';
    } else if (value.length != 10)
      return 'Mobile Number must be of 10 digit';
    else
      return null;
  }

  Future<void> userSetup(
      String fullname,
      String email,
      String vestID,
      String birthdate,
      String address,
      String phone,
      String pName,
      String pPhone) async {
    CollectionReference users =
        FirebaseFirestore.instance.collection('Patients');
    FirebaseAuth auth = FirebaseAuth.instance;
    String uid = auth.currentUser.email.toString();
    String userid = auth.currentUser.uid.toString();
    users.add({
      'fullName': fullname,
      'email': uid,
      'vestID': vestID,
      'birthdate': birthdate,
      'address': address,
      'phone': phone,
      'pName': pName,
      'pPhone': pPhone,
      'uid': userid
    });
    return;
  }

  @override
  void dispose() {
    textController.dispose();
    emailController.dispose();
    passController.dispose();
    phoneController.dispose();
    pPhoneController.dispose();
    pNameController.dispose();
    vestIDController.dispose();
    super.dispose();
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Form(
          child: Column(
        //key: _formKey,
        children: [
          SizedBox(
            height: 20.0,
          ),
          Container(
            width: size.width * .8,
            child: Text(
              'Information about Patient:',
              style: TextStyle(fontSize: 16, color: kPrimaryColor),
            ),
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Full Name',
            onChange: (value) {
              setState(() {
                _fullName = value;
              });
            },
            valid: (value) => value.isEmpty ? 'Enter Full Name' : null,
            controller: textController,
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Email',
            onChange: (value) {
              setState(() {
                _email = value;
              });
            },
            valid: (value) => value.isEmpty ? 'Enter your Email' : null,
            controller: emailController,
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Password',
            onChange: (value) {
              setState(() {
                _password = value;
              });
            },
            valid: (value) => value.isEmpty ? 'Enter your Password' : null,
            controller: passController,
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Vest ID',
            onChange: (value) {
              setState(
                () {
                  _vId = value;
                },
              );
            },
            valid: (value) => value.isEmpty ? 'Enter your Vest ID' : null,
            controller: vestIDController,
          ),
          buildTextFieldContainer(
              size: size,
              text: 'Address',
              onChange: (value) {
                setState(() {
                  _address = value;
                });
              }),
          Container(
            width: size.width * .6,
            child: TextField(
              cursorColor: kPrimaryColor,
              decoration: InputDecoration(
                hintText: _birthDate == null
                    ? 'Birthday'
                    : DateFormat('dd-MM-yyyy').format(_birthDate),
                suffixIcon: IconButton(
                    icon: Icon(
                      Icons.date_range_rounded,
                      color: kPrimaryColor,
                    ),
                    onPressed: () {
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(), // Current Date
                        firstDate: DateTime(1900), // First date
                        lastDate: DateTime(2200), // Last Date
                        builder: (BuildContext context, Widget child) {
                          return Theme(
                              data: ThemeData(
                                primarySwatch:
                                    txtColor, // Color of Ok and Cancel
                                primaryColor:
                                    kPrimaryColor, // Select date color
                                accentColor: kPrimaryColor, // Select date color
                              ),
                              child: child);
                        },
                      ).then((date) {
                        setState(() {
                          _birthDate = date;
                          _bd = _birthDate.toString();
                        });
                      });
                    }),
              ),
            ),
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Phone Number',
            onChange: (value) {
              setState(() {
                _phoneNumber = value;
              });
            },
            controller: phoneController,
            valid: validateMobile,
          ),
          SizedBox(
            height: 20.0,
          ),
          HorizontalLine(
            height: 20.0,
          ),
          SizedBox(
            height: 20.0,
          ),
          Container(
            width: size.width * .8,
            child: Text(
              'Information of person who take care about Patient:',
              style: TextStyle(fontSize: 16, color: kPrimaryColor),
            ),
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Name',
            onChange: (value) {
              setState(() {
                _pFullName = value;
              });
            },
            valid: (value) => value.isEmpty
                ? 'Enter the full name of the person who takes care about you'
                : null,
            controller: pNameController,
          ),
          buildTextFieldContainer(
            size: size,
            text: 'Phone Number',
            onChange: (value) {
              setState(() {
                _pPhoneNum = value;
              });
            },
            controller: pPhoneController,
            valid: validateMobile,
          ),
          AddButton(
            text: 'Add',
            press: () async {
              setState(() {
                showSpinner = true;
              });
              try {
                // if (_formKey.currentState.validate()) {
                final newPatient = await _auth.createUserWithEmailAndPassword(
                    email: _email, password: _password);
                type = 'patient';
                userID++;
                //createPatient();
                if (newPatient != null) {
                  userSetup(_fullName, _email, _vId, _bd, _address,
                      _phoneNumber, _pFullName, _pPhoneNum);
                }
                //}

                setState(() {
                  showSpinner = false;
                });
              } catch (e) {
                print(e);
              }
            },
          ),
        ],
      )),
    );
  }

  Container buildTextFieldContainer(
      {Size size,
      String text,
      Function onChange,
      dynamic valid,
      dynamic controller}) {
    return Container(
      width: size.width * .6,
      child: TextFormField(
        validator: valid,
        controller: controller,
        decoration: InputDecoration(
          hintText: text,
        ),
        onChanged: onChange,
      ),
    );
  }
}
