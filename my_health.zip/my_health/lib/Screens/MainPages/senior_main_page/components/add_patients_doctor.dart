import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:my_health/components/addButton.dart';
import 'package:my_health/constants.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddPatientDoctor extends StatefulWidget {
  @override
  _AddPatientDoctorState createState() => _AddPatientDoctorState();
}

class _AddPatientDoctorState extends State<AddPatientDoctor> {
  var selectedPatient, selectedDoctor;
  bool isSelected = false;

  final CollectionReference users =
      FirebaseFirestore.instance.collection('Doctors');

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: users.snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Text('Something went wrong');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Text("Loading");
        }

        return SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 10.0,
              ),
              Text(
                'Choose The Doctor: ',
                style: TextStyle(color: kPrimaryColor, fontSize: 16.0),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: ListView(
                  children: snapshot.data.docs.map((DocumentSnapshot document) {
                    return InkWell(
                      onTap: () {
                        selectedDoctor = document;
                        return showModalBottomSheet(
                            context: context,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            builder: (builder) {
                              return Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    //border: ,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  //color: Colors.white,
                                  margin: EdgeInsets.only(left: 50, right: 50),
                                  child: StreamBuilder<QuerySnapshot>(
                                      stream: FirebaseFirestore.instance
                                          .collection("Patients")
                                          .snapshots(),
                                      // ignore: missing_return
                                      builder: (context, snapshot) {
                                        // ignore: missing_return
                                        if (!snapshot.hasData) {
                                          const Text("Loading.....");
                                        } else {
                                          List<DropdownMenuItem> choosePatient =
                                              [];
                                          for (int i = 0;
                                              i < snapshot.data.docs.length;
                                              i++) {
                                            DocumentSnapshot snap =
                                                snapshot.data.docs[i];
                                            choosePatient.add(
                                              DropdownMenuItem(
                                                child: Text(
                                                  snap.data()['fullName'],
                                                  style: TextStyle(
                                                      color: kPrimaryColor),
                                                ),
                                                value: "${snap.data()['fullName']}",
                                              ),
                                            );
                                          }
                                          return Container(
                                            height: MediaQuery.of(context)
                                                    .size
                                                    .height *
                                                .5,
                                            child: Column(
                                              children: [
                                                DropdownButton(
                                                  items: choosePatient,
                                                  onChanged: (patient) async {
                                                    // ignore: missing_return, missing_return
                                                    // final snackBar = await SnackBar(
                                                    //   content: Text(
                                                    //     'Selected Patient is $patient',
                                                    //     style: TextStyle(
                                                    //         color: Color(
                                                    //             0xff1ffcb7)),
                                                    //   ),
                                                    // );
                                                    // Scaffold.of(context)
                                                    //     .showSnackBar(
                                                    //     snackBar);
                                                    setState(() {
                                                      selectedPatient = patient;
                                                    });
                                                  },
                                                  value: selectedPatient,
                                                  isExpanded: false,
                                                  hint: Text(
                                                    "Choose Patient",
                                                    style: TextStyle(
                                                        color: kPrimaryColor),
                                                  ),
                                                ),
                                                AddButton(
                                                  text: 'Add',
                                                  press: () async {
                                                    FirebaseFirestore.instance
                                                        .runTransaction((Transaction
                                                            transaction) async {
                                                      final CollectionReference
                                                          reference =
                                                          FirebaseFirestore
                                                              .instance
                                                              .collection(
                                                                  'Doctors');

                                                      await reference
                                                          .doc(document
                                                              .data()['uid'])
                                                          .collection(
                                                              'patients')
                                                          .add({
                                                        'fullName':
                                                            selectedPatient
                                                                    .data()[
                                                                'fullName'],
                                                        'email': selectedPatient
                                                            .data()['email'],
                                                        'vestID':
                                                            selectedPatient
                                                                    .data()[
                                                                'vestID'],
                                                        'birthdate':
                                                            selectedPatient
                                                                    .data()[
                                                                'birthdate'],
                                                        'address':
                                                            selectedPatient
                                                                    .data()[
                                                                'address'],
                                                        'phone': selectedPatient
                                                            .data()['phone'],
                                                        'pName': selectedPatient
                                                            .data()['pName'],
                                                        'pPhone':
                                                            selectedPatient
                                                                    .data()[
                                                                'pPhone'],
                                                        'uid': selectedPatient
                                                            .data()['uid']
                                                      });
                                                      Navigator.of(context)
                                                          .pop();
                                                    });
                                                  },
                                                )
                                              ],
                                            ),
                                          );
                                        }
                                      }));
                            });
                      },
                      child: ListTile(
                        title: Text(document.data()['fullName']),
                        subtitle: Text(document.data()['uid']),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
// class OLD extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance.collection("Patients").snapshots(),
//         // ignore: missing_return
//         builder: (context, snapshot) {
//           if (!snapshot.hasData)
//             Text("Loading.....");
//           else {
//             List<DropdownMenuItem> patientItems = [];
//             for (int i = 0; i < snapshot.data.docs.length; i++) {
//               DocumentSnapshot snap = snapshot.data.docs[i];
//               patientItems.add(
//                 DropdownMenuItem(
//                   child: Text(
//                     snap.data()['fullName'].toString(),
//                     style: TextStyle(color: kPrimaryColor),
//                   ),
//                   value: "${snap.data()['fullName'].toString()}",
//                 ),
//               );
//             }
//             return Container(
//               child: Column(
//                 children: [
//                   SizedBox(height: 30.0,),
//                   Text('Add patient to this doctor:',style: TextStyle(fontSize: 18.0,color: kPrimaryColor),),
//                   SizedBox(height: 40.0,),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: <Widget>[
//                       Icon(Icons.person,
//                           size: 25.0, color: kPrimaryColor),
//                       SizedBox(width: 50.0),
//                       DropdownButton(
//                         items: patientItems,
//                         onChanged: (patientValue) async{
//                           // final snackBar = SnackBar(
//                           //   content: Text(
//                           //     'Selected Patient $patientValue',
//                           //     style: TextStyle(color: kPrimaryColor),
//                           //   ),
//                           // );
//                           // Scaffold.of(context).showSnackBar(snackBar);
//                           setState(() {
//                             selectedPatient = patientValue;
//                             isSelected=true;
//                             userSetup(selectedPatient);
//
//
//                           });
//                         },
//                         value: selectedPatient,
//                         isExpanded: false,
//                         hint:  Text(
//                           "Choose Patient",
//                           style: TextStyle(color: kPrimaryColor),
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 20.0,),
//                   isSelected?Text('The Patient you are select is: ${selectedPatient}'):Text('Not select yet'),
//                   //SizedBox(height: MediaQuery.of(context).size.height*.3,)
//                 ],
//               ),
//             );
//           }
//         });
//   }
// }
