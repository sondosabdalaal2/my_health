import 'package:flutter/material.dart';
import 'tab_bar_container.dart';
import 'package:my_health/Screens/MainPages/senior_main_page/components/patient_list.dart';
import 'package:my_health/Screens/MainPages/senior_main_page/components/doctor_list.dart';
class DesignTab extends StatefulWidget {
  @override
  _DesignTabState createState() => _DesignTabState();
}

class _DesignTabState extends State<DesignTab> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(length: 2, child: Scaffold(
       body: SafeArea(
          child: Container(
            margin: EdgeInsets.fromLTRB(12, 0, 12, 0),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TabBarContainer(),
                  _tabContent(),
                ]),
          ),
        )
    ));
  }
  Widget _tabContent() => Expanded(
    child: TabBarView(children: [
     PatientsList(),
     DoctorsList(),
    ]),
  );

}
