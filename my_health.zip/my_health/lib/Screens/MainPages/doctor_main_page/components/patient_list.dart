import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:my_health/constants.dart';
class PatientsList extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    CollectionReference users = FirebaseFirestore.instance.collection('Patients');

    return StreamBuilder<QuerySnapshot>(
      stream: users.snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Text('Something went wrong');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Text("Loading");
        }

        return new ListView(
          children: snapshot.data.docs.map((DocumentSnapshot document) {
            return  InkWell(
              onTap: (){
              // ignore: missing_return
              showModalBottomSheet(context: context,shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ), builder: (builder){
               return Column(
                 mainAxisAlignment: MainAxisAlignment.start,
                 children: <Widget>[
                   SizedBox(height: 20.0,),
                   Text(
                     'Information',
                     style: TextStyle(
                       color: kPrimaryColor,
                       fontWeight: FontWeight.bold,
                       fontSize: 24.0,
                     ),
                   ),
                   SizedBox(
                     height: 30.0,
                   ),
                   Row(
                     mainAxisAlignment: MainAxisAlignment.start,
                     children: [
                       SizedBox(
                         width: 20.0,
                       ),
                       Text('Name: ',style: TextStyle(
                           color: Colors.black,
                           fontWeight: FontWeight.bold,
                           fontSize: 16.0),),
                       Text(
                         document.data()['fullName'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 14.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 20.0,
                   ),
                   Row(
                     children: [
                       SizedBox(
                         width: 20.0,
                       ),
                       Text(
                         'Email: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 16.0),
                       ),
                       Text(
                         document.data()['email'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 14.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 20.0,
                   ),
                   Row(
                     children: [
                       SizedBox(
                         width: 20.0,
                       ),
                       Text(
                         'Phone Number: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 16.0),
                       ),
                       Text(
                         document.data()['phone'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 14.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 20.0,
                   ),
                   // Align(
                   //   alignment: Alignment.centerLeft,
                   //   child: Row(
                   //     children: [
                   //       Text(
                   //         'User ID',
                   //         style: TextStyle(
                   //             color: Colors.black,
                   //             fontWeight: FontWeight.bold,
                   //             fontSize: 16.0),
                   //       ),
                   //       Text(
                   //         document.data()['uid'],
                   //         style: TextStyle(
                   //             color: Colors.black,
                   //             fontWeight: FontWeight.bold,
                   //             fontSize: 16.0),
                   //       ),
                   //     ],
                   //   ),
                   // ),
                   Row(
                     children: [
                       SizedBox(
                         width: 20.0,
                       ),
                       Text(
                         'User ID: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 16.0),
                       ),
                       Text(
                         document.data()['uid'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 14.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 20.0,
                   ),
                   Row(
                     children: [
                       SizedBox(
                         width: 20.0,
                       ),
                       Text(
                         'Vest ID: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 16.0),
                       ),
                       Text(
                         document.data()['vestID'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 14.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 20.0,
                   ),
                   // Align(
                   //   alignment: Alignment.centerLeft,
                   //   child: Row(
                   //     children: [
                   //       Text(
                   //         'User ID',
                   //         style: TextStyle(
                   //             color: Colors.black,
                   //             fontWeight: FontWeight.bold,
                   //             fontSize: 16.0),
                   //       ),
                   //       Text(
                   //         document.data()['uid'],
                   //         style: TextStyle(
                   //             color: Colors.black,
                   //             fontWeight: FontWeight.bold,
                   //             fontSize: 16.0),
                   //       ),
                   //     ],
                   //   ),
                   // ),
                   Row(
                     children: [
                       SizedBox(
                         width: 20.0,
                       ),
                       Text(
                         'Person who take care about him: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 16.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 15.0,
                   ),
                   Row(
                     children: [
                       SizedBox(
                         width: 50.0,
                       ),
                       Text(
                         'Name: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,
                             fontSize: 14.0),
                       ),
                       Text(
                         document.data()['pName'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 16.0),
                       ),
                     ],
                   ),
                   SizedBox(
                     height: 15.0,
                   ),
                   Row(
                     children: [
                       SizedBox(
                         width: 50.0,
                       ),
                       Text(
                         'Phone Number: ',
                         style: TextStyle(
                             color: Colors.black,
                             fontWeight: FontWeight.bold,

                             fontSize: 14.0),
                       ),
                       Text(
                         document.data()['pPhone'],
                         style: TextStyle(
                             color: Colors.black,
                             fontSize: 14.0),
                       ),
                     ],
                   ),
                   ClipRRect(

                     child: TextButton(
                       style: TextButton.styleFrom(
                         padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
                         backgroundColor: kPrimaryColor,
                       ),
                       onPressed: (){
                         //TODO:GO To All Result page
                       },
                       child: Align(
                         alignment: Alignment.center,
                         child: Text(
                           'All Result',
                           style: TextStyle(color: Colors.white),
                         ),
                       ),
                     ),
                   ),
                 ],
               );
              });
              },
              child: ListTile(
                title:  Text(document.data()['fullName']),
                subtitle:  Text(document.data()['email']),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
