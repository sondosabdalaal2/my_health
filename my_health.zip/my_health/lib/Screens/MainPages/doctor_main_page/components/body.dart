import 'package:flutter/material.dart';
import 'background.dart';
import 'placeholder_widget.dart';
class Body extends StatefulWidget {
  final name;
  final email;
  final birth;
  final phone;
  final ID;
  Body({this.name,this.email,this.phone,this.birth,this.ID});

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  final List<Widget> _children = [
    PlaceholderWidget(Container()),
    PlaceholderWidget(Container()),
    PlaceholderWidget(Container()),

  ];

  @override
  Widget build(BuildContext context) {
    return Background(
      name: widget.name,
      email: widget.email,
      phone: widget.phone,
      birth: widget.birth,
      ID: widget.ID,
      child:_children[_currentIndex],
      builBottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        //backgroundColor: kPrimaryColor,
        onTap: onTabTapped, // new
        currentIndex: _currentIndex, // new
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'New Patient',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
