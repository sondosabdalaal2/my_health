package appbrewer.my_health

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
